# nlp-java: Simplified Yorùbá Natural Language Interpreter

A lightweight, 100% Java natural language interpreter for Yorùbá. It tokenizes input sentences, normalizes diacritics, maps words to their parts of speech, and outputs phonetic IPA readings. It also features automatic syntax validation for Subject-Verb-Object (SVO) structures and spelling suggestions using edit distance.

---

## How to Compile and Run

Make sure you have the Java Development Kit (JDK 21 or later) installed.

```bash
# Navigate to the project root
cd /home/amari/nlp-java

# Compile Java classes
javac nlp/*.java

# Run the program
java nlp.Main
```

---

## Interaction Examples

### Valid Sentence (SVO Parse)
```text
>>> mo ra aṣọ

═══ LEXICAL ANALYSIS ═══
  Word: mo       | Category: PRONOUN  | IPA: /mō/
  Word: ra       | Category: VERB     | IPA: /ɾà/
  Word: aṣọ      | Category: NOUN     | IPA: /ā.ʃɔ̄/

═══ PHONETIC READING ═══
  Full Pronunciation: /mō /ɾà/ /ā.ʃɔ̄/
```

### Syntax Error
```text
>>> ra mo aṣọ
Syntax Error: Sentence must start with a Subject (Noun/Pronoun) at 'ra'.
```

### Lexical Correction
```text
>>> mo ra awso
Lexical Error: Unrecognized word 'awso'.
Did you mean 'aso'? (y/n): y
```
