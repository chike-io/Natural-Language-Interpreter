package nlp;

import java.util.List;

public class Parser {
    public static void validate(List<Lexer.Token> tokens) throws Exception {
        if (tokens.isEmpty()) {
            throw new Exception("Syntax Error: Empty sentence.");
        }

        // Validate Subject (First token must be PRONOUN or NOUN)
        Lexer.Token first = tokens.get(0);
        if (first.category() != Lexer.Category.PRONOUN && first.category() != Lexer.Category.NOUN) {
            throw new Exception("Syntax Error: Sentence must start with a Subject (Noun/Pronoun) at '" + first.original() + "'.");
        }

        if (tokens.size() == 1) {
            throw new Exception("Syntax Error: Incomplete sentence. Expected a Verb after the Subject.");
        }

        // Validate Verb (Second token must be VERB)
        Lexer.Token second = tokens.get(1);
        if (second.category() != Lexer.Category.VERB) {
            throw new Exception("Syntax Error: Expected a Verb after the Subject, found '" + second.original() + "' (" + second.category() + ").");
        }

        // Validate Object (Optional third token must be PRONOUN or NOUN)
        if (tokens.size() == 3) {
            Lexer.Token third = tokens.get(2);
            if (third.category() != Lexer.Category.PRONOUN && third.category() != Lexer.Category.NOUN) {
                throw new Exception("Syntax Error: Expected Object (Noun/Pronoun) at the end, found '" + third.original() + "' (" + third.category() + ").");
            }
        }

        if (tokens.size() > 3) {
            throw new Exception("Syntax Error: Sentence exceeds SV/SVO limits. Extra tokens found starting from '" + tokens.get(3).original() + "'.");
        }
    }
}
