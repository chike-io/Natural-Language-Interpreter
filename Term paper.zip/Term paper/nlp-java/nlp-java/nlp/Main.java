package nlp;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        // 1. Language Selector Module
        System.out.println("═══ LANGUAGE SELECTOR ═══");
        System.out.println("Initializing Natural Language Interpreter...");
        System.out.println("Default Language: Yorùbá");
        System.out.println("=========================\n");

        Lexer lexer = new Lexer();
        try {
            System.out.println("Loading lexicon from 'data/lexicon.tsv'...");
            lexer.loadLexicon("data/lexicon.tsv");
            System.out.println("Lexicon loaded successfully.\n");
        } catch (Exception e) {
            System.err.println("Fatal Error: Could not load lexicon file: " + e.getMessage());
            System.err.println("Make sure to run the program from the project root (/home/amari/nlp-java) containing the 'data' folder.");
            return;
        }

        System.out.println("nlp-java: Interactive Yorùbá Natural Language Interpreter");
        System.out.println("Enter a sentence (e.g., 'mo ra aṣọ', 'ọkọ tobi'). Type 'exit' to quit.\n");

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print(">>> ");
            String input = scanner.nextLine().trim();
            if (input.equalsIgnoreCase("exit")) break;
            if (input.isEmpty()) continue;

            List<Lexer.Token> tokens = lexer.tokenize(input);
            List<Lexer.Token> processedTokens = new ArrayList<>();
            boolean hasLexicalError = false;

            // 2. Lexical Analysis & Spelling suggestions (HMPT / Error Correction Loop)
            for (Lexer.Token token : tokens) {
                if (token.category() == Lexer.Category.UNKNOWN) {
                    System.out.println("Lexical Error: Unrecognized word '" + token.original() + "'.");
                    String suggestion = suggestCorrection(token.original(), lexer.getVocabulary());
                    if (suggestion != null) {
                        System.out.print("Did you mean '" + suggestion + "'? (y/n): ");
                        String response = scanner.nextLine().trim();
                        if (response.equalsIgnoreCase("y")) {
                            processedTokens.addAll(lexer.tokenize(suggestion));
                            continue;
                        }
                    }
                    hasLexicalError = true;
                }
                processedTokens.add(token);
            }

            if (hasLexicalError) {
                System.out.println("Interpreter execution halted due to Lexical Errors.\n");
                continue;
            }

            // 3. Syntax Validation & Parsing
            try {
                Parser.validate(processedTokens);
                
                // 4. Print Output and Lexical POS Table
                System.out.println("\n═══ LEXICAL ANALYSIS ═══");
                for (Lexer.Token t : processedTokens) {
                    System.out.printf("  Word: %-8s | Category: %-8s | IPA: /%s/%n", t.original(), t.category(), t.ipa());
                }

                // 5. Phonetic Reading Output
                System.out.println("\n═══ PHONETIC READING ═══");
                List<String> ipas = new ArrayList<>();
                for (Lexer.Token t : processedTokens) {
                    ipas.add(t.ipa());
                }
                System.out.println("  Full Pronunciation: /" + String.join(" ", ipas) + "/");
                System.out.println();

            } catch (Exception e) {
                System.out.println(e.getMessage() + "\n");
            }
        }
        scanner.close();
    }

    private static String suggestCorrection(String word, Set<String> vocabulary) {
        String best = null;
        int minDistance = 3; // Levenshtein threshold
        for (String known : vocabulary) {
            int d = levenshtein(word, known);
            if (d < minDistance) {
                minDistance = d;
                best = known;
            }
        }
        return best;
    }

    private static int levenshtein(String a, String b) {
        int[] costs = new int[b.length() + 1];
        for (int j = 0; j < costs.length; j++) costs[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            costs[0] = i;
            int nw = i - 1;
            for (int j = 1; j <= b.length(); j++) {
                int cj = Math.min(1 + Math.min(costs[j], costs[j - 1]), 
                                  a.charAt(i - 1) == b.charAt(j - 1) ? nw : nw + 1);
                nw = costs[j];
                costs[j] = cj;
            }
        }
        return costs[b.length()];
    }
}
