package nlp;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.*;

public class Lexer {
    public enum Category { PRONOUN, NOUN, VERB, UNKNOWN }
    public record WordInfo(Category category, String ipa) {}
    public record Token(String original, Category category, String ipa) {}

    private final Map<String, WordInfo> dictionary = new HashMap<>();

    public void loadLexicon(String filePath) throws IOException {
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream(filePath), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                
                String[] parts = line.split("\t");
                if (parts.length >= 3) {
                    String word = stripDiacritics(parts[0].trim().toLowerCase());
                    Category category = Category.valueOf(parts[1].trim().toUpperCase());
                    String ipa = parts[2].trim();
                    // Prefer the first definition found in the file
                    if (!dictionary.containsKey(word)) {
                        dictionary.put(word, new WordInfo(category, ipa));
                    }
                }
            }
        }
    }

    public List<Token> tokenize(String input) {
        List<Token> tokens = new ArrayList<>();
        String[] words = input.toLowerCase().split("\\s+");
        for (String word : words) {
            String cleanWord = stripDiacritics(word);
            // Explicitly resolve the common pronoun 'mo' (I) to prevent conflict with verb 'mọ' (to know)
            if (cleanWord.equals("mo")) {
                tokens.add(new Token(word, Category.PRONOUN, "mō"));
            } else {
                WordInfo info = dictionary.get(cleanWord);
                if (info != null) {
                    tokens.add(new Token(word, info.category(), info.ipa()));
                } else {
                    tokens.add(new Token(word, Category.UNKNOWN, ""));
                }
            }
        }
        return tokens;
    }

    private String stripDiacritics(String word) {
        if (word == null) return "";
        // Decompose unicode characters to separate letters from combining marks
        String nfd = Normalizer.normalize(word, Normalizer.Form.NFD);
        // Strip acute, grave, macron, and under-dots (dots below)
        String stripped = nfd.replaceAll("[\\u0300\\u0301\\u0323\\u0304]", "");
        // Recompose and return normalized lowercase form
        return Normalizer.normalize(stripped, Normalizer.Form.NFC).toLowerCase().trim();
    }

    public Set<String> getVocabulary() {
        return dictionary.keySet();
    }
}
